from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

application = Flask(__name__)

# Dictionary to store todo items with dates
todo_list = {}


@application.route('/')
def index():
    return render_template('index.html', todo_list=todo_list)


@application.route('/add', methods=['POST'])
def add():
    todo_item = request.form['todo_item']
    todo_date = request.form['todo_date']

    if todo_date not in todo_list:
        todo_list[todo_date] = []

    todo_list[todo_date].append({'task': todo_item, 'completed': False})
    return redirect(url_for('index'))


@application.route('/remove', methods=['POST'])
def remove():
    completed_tasks = request.form.getlist('completed_task')
    for task in completed_tasks:
        date, index = task.split('|')
        todo_list[date][int(index)]['completed'] = True

    # Remove dates with no tasks
    todo_list_keys = list(todo_list.keys())
    for date in todo_list_keys:
        if not any(not task['completed'] for task in todo_list[date]):
            del todo_list[date]

    return redirect(url_for('index'))


if __name__ == '__main__':
    application.run(debug=True)
